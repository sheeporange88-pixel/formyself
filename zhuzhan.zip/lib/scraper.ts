import fs from "fs";

async function initStealthPuppeteer() {
  const puppeteerExtra = (await import("puppeteer-extra")).default;
  const StealthPlugin = (await import("puppeteer-extra-plugin-stealth")).default;
  puppeteerExtra.use(StealthPlugin());
  return puppeteerExtra;
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

// ✅ get Arc'teryx  slug
function slugify(name: string) {
  return name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/['".]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export async function fetchAllProducts(url: string) {
  const puppeteer = await initStealthPuppeteer();
  let products: any[] = [];

  const browser = await puppeteer.launch({
    headless: false,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
    ],
    defaultViewport: { width: 1366, height: 900 },
  });

  try {
    const page = await browser.newPage();

    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0 Safari/537.36"
    );
    await page.setExtraHTTPHeaders({
      "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    });

    // 🍪 get cookies.json  or .env  
    if (fs.existsSync("cookies.json")) {
      try {
        let cookies = JSON.parse(fs.readFileSync("cookies.json", "utf-8"));
        cookies = cookies.map((c: any) => {
          const fixed = { ...c };
          if (
            typeof fixed.sameSite !== "string" ||
            !["Strict", "Lax", "None"].includes(fixed.sameSite)
          )
            delete fixed.sameSite;
          if (fixed.expires && typeof fixed.expires !== "number")
            delete fixed.expires;
          return fixed;
        });
        await page.setCookie(...cookies);
        console.log(`🍪 已从 cookies.json 注入 ${cookies.length} 条（清洗后）`);
      } catch (e) {
        console.warn("⚠️ 读取 cookies.json 失败:", e);
      }
    } else if (process.env.ARCTERYX_COOKIE) {
      const cookiePairs = process.env.ARCTERYX_COOKIE.split(";").map((c) => {
        const [name, ...rest] = c.trim().split("=");
        return { name, value: rest.join("="), domain: ".arcteryx.com" };
      });
      await page.setCookie(...cookiePairs);
      console.log("🍪 已从 .env 注入自定义 Cookie");
    }

    console.log("🔗 打开页面:", url);
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
    await delay(5000);
    await page.screenshot({ path: "page_debug.png", fullPage: true });
    console.log("📸 已保存截图 page_debug.png");

    // === 滚动懒加载 ===
    let lastHeight = await page.evaluate("document.body.scrollHeight");
    let scroll = 0;
    while (true) {
      await page.evaluate("window.scrollTo(0, document.body.scrollHeight)");
      await delay(1500);
      const newHeight = await page.evaluate("document.body.scrollHeight");
      scroll++;
      console.log(`↕️ 滚动第 ${scroll} 次`);
      if (newHeight === lastHeight || scroll > 25) break;
      lastHeight = newHeight;
    }

    // === 抓取数据（适配 Outlet 结构） ===
    products = await page.evaluate(() => {
      const list: any[] = [];
      document.querySelectorAll("a.qa--product-tile__link").forEach((el) => {
        const nameEl = el.querySelector(".sc-c100b712-307") as HTMLElement;
        const priceEl =
          (el.querySelector(".qa--product-tile__price") as HTMLElement) ||
          (el.querySelector(".qa--product-tile__original-price") as HTMLElement);

        const name = nameEl?.innerText?.trim();
        const price = priceEl?.innerText?.trim();
        const href = (el as HTMLAnchorElement)?.getAttribute("href");

        if (name && price && href)
          list.push({
            name,
            price,
            link: `https://arcteryx.com${href}`,
          });
      });
      return list;
    });

    console.log(`✅ 抓取完成，共 ${products.length} 条`);

    //  save cookie
    const newCookies = await page.cookies();
    fs.writeFileSync("cookies.json", JSON.stringify(newCookies, null, 2));
    console.log(` saved cookie (${newCookies.length}  )  in  cookies.json`);
  } catch (e) {
    console.error("抓取失败:", e);
  } finally {
    await browser.close();
  }

  // get  product info
  return products.map((p) => ({
    ...p,
    slug: slugify(p.name),
  }));
}
