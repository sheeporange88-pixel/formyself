let baseline: any[] = [];
let initialized = false;

export function getBaseline() {
  return baseline;
}
export function setBaseline(data: any[]) {
  baseline = data;
}
export function isInitialized() {
  return initialized;
}
export function setInitialized(v: boolean) {
  initialized = v;
}
