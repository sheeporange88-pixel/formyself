function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function sendTelegramBatch(
  chatId: string,
  products: { name: string; link: string; price: string }[],
  title: string
) {
  console.log(`📨 准备发送 Telegram 消息 (${products.length} 条)`);

  const token = process.env.TELEGRAM_BOT_TOKEN!;
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  const batchSize = Number(process.env.TELEGRAM_BATCH_SIZE || 10);

  const now = new Date();
  const timestamp = now.toLocaleString("zh-CN", { hour12: false });

  for (let i = 0; i < products.length; i += batchSize) {
    const group = products.slice(i, i + batchSize);
    const message =
      `🕒 *${title}* — ${timestamp}\n(共 ${group.length} 条)\n\n` +
      group
        .map(
          (p, idx) =>
            `${i + idx + 1}. [${p.name}](${p.link})\n💶 ${p.price}`
        )
        .join("\n\n");

    let success = false;
    while (!success) {
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: "Markdown",
            disable_web_page_preview: true,
          }),
        });

        const result = await res.json();

        if (result.ok) {
          console.log(`✅ Telegram 已发送 (${i + 1}-${i + group.length})`);
          success = true;
          await delay(2000);
        } else if (result.error_code === 429) {
          const wait = (result.parameters?.retry_after || 5) * 1000;
          console.warn(`⏳ Telegram 限速，等待 ${wait / 1000}s`);
          await delay(wait);
        } else {
          console.error("❌ Telegram 发送失败:", result);
          success = true;
        }
      } catch (err) {
        console.error("🚨 Telegram 请求异常:", err);
        await delay(5000);
      }
    }
  }
}
