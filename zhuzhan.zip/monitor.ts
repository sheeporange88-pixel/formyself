import * as dotenv from "dotenv";
dotenv.config({ path: ".env.local" });

import { fetchAllProducts } from "./lib/scraper";
import { sendTelegramBatch } from "./lib/telegram";

let baseline: any[] = [];
let isSending = false;
const URL = "https://arcteryx.com/de/en/c/mens/new-arrivals";

async function checkProducts() {
  if (isSending) {
    console.log(" ignore this time。");
    return;
  }

  console.log("🔍 开始检查商品...");

  const newList = await fetchAllProducts(URL);
  if (newList.length === 0) {
    console.warn("⚠️ 抓取为空，跳过对比");
    return;
  }

  // === 第一次运行：发送全部 ===
  if (baseline.length === 0) {
    baseline = newList;
    console.log(`✅ first time base line，共 ${newList.length} 条`);
    isSending = true;
    await sendTelegramBatch(
      process.env.TELEGRAM_CHAT_ID!,
      newList,
      "📦 首次同步全部商品"
    );
    isSending = false;
    return;
  }

  // === 对比基线 ===
  const newItems = newList.filter(
    (p) => !baseline.some((b) => b.link === p.link)
  );
  const changed = newList.filter((p) => {
    const old = baseline.find((b) => b.link === p.link);
    return old && old.price !== p.price;
  });

  if (newItems.length === 0 && changed.length === 0) {
    console.log("✅ 无变化（稳定）");
    return;
  }

  isSending = true;

  if (newItems.length > 0) {
    await sendTelegramBatch(
      process.env.TELEGRAM_CHAT_ID!,
      newItems,
      "🆕 新上架商品"
    );
  }

  if (changed.length > 0) {
    await sendTelegramBatch(
      process.env.TELEGRAM_CHAT_ID!,
      changed,
      "💸 价格变化"
    );
  }

  console.log(
    `📊 本轮检测变化：上新 ${newItems.length} 条，价格变化 ${changed.length} 条`
  );

  // === 更新基线 ===
  baseline = newList;

  isSending = false;
}

// === 主流程 ===
console.log("🚀 启动始祖鸟监控服务...");
console.log("Using token:", process.env.TELEGRAM_BOT_TOKEN?.slice(0, 10));
console.log("Using chatId:", process.env.TELEGRAM_CHAT_ID);

checkProducts();
setInterval(checkProducts, 1000 * 60 * 6); // 每3分钟轮询
